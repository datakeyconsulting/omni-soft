package dsi.met;

import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import dsi.met.dao.TaskRepository;
import dsi.met.entities.AppRole;
import dsi.met.entities.AppUser;
import dsi.met.entities.Task;
import dsi.met.service.AccountService;

@SpringBootApplication
public class AuthentificationApplication implements CommandLineRunner {

	@Autowired
	TaskRepository taskRepository;

	@Autowired
	AccountService accountService;

	public static void main(String[] args) {
		SpringApplication.run(AuthentificationApplication.class, args);
	}

	@Bean
	public BCryptPasswordEncoder getBCPE() {
		return new BCryptPasswordEncoder();
	}

	@Override

	public void run(String... args) throws Exception {
		accountService.saveUser(new AppUser(null, "admin", "1234", null));
		accountService.saveUser(new AppUser(null, "user", "1234", null));
		
		accountService.saveRole(new AppRole(null, "ADMIN"));
		accountService.saveRole(new AppRole(null, "USER"));
		
		accountService.addRoleToUser("admin", "ADMIN");
		accountService.addRoleToUser("admin", "USER");
		accountService.addRoleToUser("user", "USER");
		
		Stream.of("T1", "T2", "T3").forEach(t -> {
			taskRepository.save(new Task(null, t));
		});
		
		AppUser u = accountService.findUserByUsername("admin");
		System.out.println(u.getUsername());
		System.out.println(u.getPassword());
		u.getRoles().forEach(r -> System.out.println(r.getRoleName()));
		

		taskRepository.findAll().forEach(t -> System.out.println(t.getTaskName()));
	}

}
