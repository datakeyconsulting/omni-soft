package dsi.met.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import dsi.met.dao.TaskRepository;
import dsi.met.entities.Task;
import dsi.met.entities.UserCics;

@RestController
public class TaskRestController {

	@Autowired
	private TaskRepository taskRepository;
	
	@GetMapping("/")
	public String home() {
		System.out.println("===========String home()==========");
		return "Success";
	}

	@GetMapping("/tasks")
	public List<Task> listTasks() {
		return taskRepository.findAll();
	}

	@PostMapping("/tasks")
	Task save(@RequestBody Task t) {
		return taskRepository.save(t);
	}
	
	@GetMapping("/user")
	public UserCics getUserCics() {
		UserCics user = new UserCics();
		List<String> roles = new ArrayList<>();
		roles.add("TGPCONSULT");
		roles.add("TGPCONSULT");
		user.setRoles(roles);
		user.setUsername("aden024");
		user.setPassword("1234");
		return user;
	}


}


/*

{"username":"aden024","firstname":"DEUNGOUE YANN","lastname":"DEUNGOUE YANN","authorities":["TGPCONSULT","TGPCONSULT"]}
*/