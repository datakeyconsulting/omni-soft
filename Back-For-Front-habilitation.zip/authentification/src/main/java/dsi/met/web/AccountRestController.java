package dsi.met.web;

public class AccountRestController {

}
