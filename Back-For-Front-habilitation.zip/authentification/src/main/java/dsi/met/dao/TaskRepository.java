package dsi.met.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import dsi.met.entities.Task;

public interface TaskRepository extends JpaRepository<Task, Long> {

}
