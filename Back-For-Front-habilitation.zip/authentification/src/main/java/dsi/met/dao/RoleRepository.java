package dsi.met.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import dsi.met.entities.AppRole;

public interface RoleRepository extends JpaRepository<AppRole, Long> {

	public AppRole findByRoleName(String roleName);

}
