package dsi.met.config.sec;

public class SecurityConstants {
	public static final String HEADER_STRING = "Authorization";

}
